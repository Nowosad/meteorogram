#setwd("~/R/skryptydoR/gis/")
library(rgdal)
library(automap)
library(dplyr)
library(gstat)
library(sp)
library(raster)
library(matlab)
library(fields)
# twoja funkcja
par_krige <- function(form, point, grid, model, ncores, ...){
  clus <- c(rep("localhost", ncores))
  ncell <- dim(coordinates(grid))[1] ##UWAGA!!
  # set up cluster and data
  cl <- makeCluster(clus, type = "SOCK")
  clusterEvalQ(cl, library(gstat))
  
  # form_chr <- deparse(substitute(form))
  point_chr <- deparse(substitute(point))
  grid_chr <- deparse(substitute(grid))
  model_chr <- deparse(substitute(model))
  clusterExport(cl, list(point_chr, grid_chr, model_chr), envir=environment())
  
  splt  <- rep(1:ncores, each = ceiling(ncell/ncores), length.out = ncell)
  new_grids <- lapply(as.list(1:ncores), function(w) grid[splt == w, ])
  
  result <- do.call("rbind", parLapply(cl, new_grids, function(lst)
    krige(form, point, newdata=lst, model=model, ...)))
  stopCluster(cl)
  return(result)
}



# dane z ogimetu
tabelka <- readRDS("xym.rda")

#################################################################
############ Koniec pobierania danych z ogimetu #################
####### rozpoczecie zabaw z krigingiem regresyjnym ##############
#######       wedlug tutoriala Tomislava Hengla
#################################################################


indeksy=match(as.character(xym$name),as.character(tabelka$data_synop))
a=cbind(xym,tabelka[indeksy,])
a=a[which(a$lon>13.7 & a$lon<24.6 & a$lat>48.8 &a$lat<55),]

a=a[-which(a$name=="Snezka"),]

a2=a
a=a2[,c(1:5,7:22)]

colnames(a)[c(1,2,5)]=c("X","Y","name")
#a=a[,1:8]
coordinates(a)=~X+Y

slope <- read.asciigrid("elevation.asc", as.image=FALSE, plot.image=TRUE)
names(slope)="slope.asc"
slope$lon=coordinates(slope)[,1]
slope$lat=coordinates(slope)[,2]

slope.ov = over(a, slope)
a$slope.asc =slope.ov$slope.asc   # copy the slope values
b=coordinates(a)
a$lon=b[,1]
a$lat=b[,2]

lm.depth <- step(lm(tmin~slope.asc+lon+lat, a))
tmp=summary(lm.depth)
# plot(tmin~slope.asc+lon+lat, as.data.frame(a))
# abline(lm(DEPTH~slope.asc, as.data.frame(a)))

# tmin
atmin=a[-which(is.na(a$tmin)),]
null.vgm <- vgm(var(atmin$tmin), "Exp", sqrt(areaSpatialGrid(slope))/4, nugget=2) # initial parameters
vgm_depth_r <- fit.variogram(variogram(formula(lm.depth), atmin), model=null.vgm)
vgm_depth_r2 <- autofitVariogram(formula(lm.depth), input_data = atmin, verbose = T)
vgm_depth_r <- vgm_depth_r2$var_model # podmianka variogramow
plot(variogram(formula(lm.depth),atmin), vgm_depth_r, main="fitted by gstat")
system.time(tmin <- krige(formula(lm.depth), locations=atmin, newdata=slope, model=vgm_depth_r))
#using universal kriging]
#uzytkownik     system   uplynelo
#148.469      0.276    148.893 
spplot(tmin)

# proba z twoja funkcja:
library(snow) # tego brakowalo

system.time(k4 <- par_krige(form=tmin ~ slope.asc + lon + lat, point=atmin, grid=slope, model=vgm_depth_r, ncores=3))

# 
# > system.time(k4 <- par_krige(form=tmin ~ slope.asc + lon + lat, point=atmin, grid=slope, model=vgm_depth_r, ncores=3))
# Błąd w poleceniu 'rbind2(..1, r)':
#   brak metody dla przekształcenia tej klasy S4 na wektor
# Dodatkowo: Komunikaty ostrzegawcze:
# 1: zamykanie nieużywanego połączenia 5 (<-localhost:11911) 
# 2: zamykanie nieużywanego połączenia 4 (<-localhost:11911) 
# 3: zamykanie nieużywanego połączenia 3 (<-localhost:11911)
# Called from: rbind2(..1, r)
# Browse[1]> Q
# Timing stopped at: 2.253 0.577 357.219